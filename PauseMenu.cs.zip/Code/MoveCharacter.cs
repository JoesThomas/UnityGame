﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]

public class MoveCharacter : CheckValues
{

    public float speed = 2.0f;
    public float LocationYOfPlayer;
    public float LocationXOfPlayer;
    public Vector3 position;
    public Transform tr;
    public Animator animator;

    void Start()
    {
        position = transform.position;
        tr = transform;
    }

    // Update is called once per frame




    void Update()
    {
        animator.SetFloat("Horizontal", Input.GetAxis("Horizontal"));

        if (PlayerStop == false)
        {
            LocationXOfPlayer = transform.position.x;
            LocationYOfPlayer = transform.position.y;
            if (Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow))
            {
                position += Vector3.right;
            }
            else if (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow))
            {
                position += Vector3.left;
            }
            else if (Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow))
            {
                position += Vector3.up;
            }
            else if (Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow))
            {
                position += Vector3.down;
            }

            transform.position = Vector3.MoveTowards(transform.position, position, Time.deltaTime * speed);
        }
    }
}
