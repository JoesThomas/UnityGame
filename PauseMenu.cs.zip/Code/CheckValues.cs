﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]

public class CheckValues : MonoBehaviour
{
    public bool water;
    public bool Walls;
    public bool Rock;
    public bool Bone;
    public bool PlayerStop;
    public float X;
    public float Y;
    string[] verbs = {"WaterPixel","WallPixel","RockPixel","DogPixel","BonePixel"};
    string[] nouns = {"WetPixel","StopPixel","MovePixel","WinPixel","MePixel"};
    bool[] verbBool = new bool[5];
    bool[] nounBool = new bool[5];
    Collider2D[] hitcolliders;
    Vector3 northCheck;
    Vector3 southCheck;
    Vector3 eastCheck;
    Vector3 westCheck;

    // Start is called before the first frame update
    void Start()
    {
      
    }
    // Update is called once per frame
    void Update()
    {
        north();
        south();
        east();
        west();
        if (verbBool[0] == true && nounBool[0] == true)
        {
            Debug.Log("Water is " + water);

            water = true;
        }
        else { water = false; }
        if (verbBool[1] == true && nounBool[1] == true)
        {
            Debug.Log("Wall is " + Walls);
            Walls = true;

        }
        else { Walls = false; }
        if (verbBool[2] == true && nounBool[2] == true)
        {
            Rock = true;
        }
        else { Rock = false; }
        if (verbBool[3] == true && nounBool[3] == true)
        {
            Bone = true;
        }
        else { Bone = false; }
        if (verbBool[4] == true && nounBool[4] == true)
        {
            PlayerStop = true;
        }
        else { PlayerStop = false; }
    }
    void north()
    {
        Vector3 loc = new Vector3(transform.position.x, transform.position.y, 0);
        X = transform.position.x;
        Y = transform.position.y;
        northCheck = new Vector3((loc.x), (loc.y) + 1, 0);
        hitcolliders = Physics2D.OverlapCircleAll(northCheck, 0.0f);
        if (hitcolliders.Length != 0)
        {
            for (int a = 0; a < verbs.Length - 1; a++)
            {
                string verbValue = verbs[a];
                if (hitcolliders[0].gameObject.name == verbValue)
                {
                    verbBool[a] = true;
                }
            }
            for (int b = 0; b < nouns.Length; b++)
            {
                string nounValue = nouns[b];
                if (hitcolliders[0].gameObject.name == nounValue)
                {
                    nounBool[b] = true;
                }
            }
        }
    }
    void south()
    {
        Vector3 loc = new Vector3(transform.position.x, transform.position.y, 0);
        X = transform.position.x;
        Y = transform.position.y;
        southCheck = new Vector3((loc.x), (loc.y - 1), 0);
        hitcolliders = Physics2D.OverlapCircleAll(southCheck, 0.0f);
        if (hitcolliders.Length != 0)
        {
            for (int a = 0; a < verbs.Length-1; a++)
        {
            string verbValue = verbs[a];
            if (hitcolliders[0].gameObject.name == verbValue)
            {
                verbBool[a] = true;
            }
        }
            for (int b = 0; b < nouns.Length; b++)
            {
                string nounValue = nouns[b];
                if (hitcolliders[0].gameObject.name == nounValue)
                {
                    nounBool[b] = true;
                }
            }
        }
    }
    void east()
    {
        Vector3 loc = new Vector3(transform.position.x, transform.position.y, 0);
        X = transform.position.x;
        Y = transform.position.y;
        eastCheck = new Vector3((loc.x + 1), (loc.y), 0);
        hitcolliders = Physics2D.OverlapCircleAll(eastCheck, 0.0f);
        if (hitcolliders.Length != 0)
        {
            for (int a = 0; a < verbs.Length; a++)
            {
                string verbValue = verbs[a];

                {
                    if (hitcolliders[0].gameObject.name == verbValue)
                    {
                        verbBool[a] = true;
                    }
                }
                for (int b = 0; b < nouns.Length; b++)
                {
                    string nounValue = nouns[b];
                    if (hitcolliders[0].gameObject.name == nounValue)
                    {
                        nounBool[b] = true;
                    }
                }
            }
        }
    }
    void west()
    {
        Vector3 loc = new Vector3(transform.position.x, transform.position.y, 0);
        X = transform.position.x;
        Y = transform.position.y;
        westCheck = new Vector3((loc.x - 1), (loc.y), 0);
        hitcolliders = Physics2D.OverlapCircleAll(westCheck, 0.0f);
        if (hitcolliders.Length != 0)
        {

            for (int a = 0; a < verbs.Length - 1; a++)
            {
                string verbValue = verbs[a];
                if (hitcolliders[0].gameObject.name == verbValue)
                {
                    verbBool[a] = true;
                }
            }
            for (int b = 0; b < nouns.Length; b++)
            {
                string nounValue = nouns[b];
                if (hitcolliders[0].gameObject.name == nounValue)
                {
                    nounBool[b] = true;
                }
            }
        }
    }
}
