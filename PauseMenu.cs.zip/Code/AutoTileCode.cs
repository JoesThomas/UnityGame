﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class AutoTileCode : MonoBehaviour
{

    public float X;
    public float Y;     
    public Tile Shore;
    public Tilemap beach;
    public Vector3Int shorePos = new Vector3Int(0, 0, 0);
    public Vector3 newLoc = new Vector3(0, 0, 0.0f);


    // Start is called before the first frame update
    void Start()
    {
        X = transform.position.x;
        Y = transform.position.y;
        int xMax = 9;
        int yMax = 7;

        for (int xMin = -8; xMin < xMax; xMin++)
        {
            for (int yMin = -6; yMin < yMax; yMin++)
            {
                Vector3 loc = new Vector3(xMin, yMin, 0);
                Collider2D[] hitcolliders = Physics2D.OverlapCircleAll(loc, 0.0f);
                for (int i = 0; i < hitcolliders.Length; i++)
                {
                    Debug.Log("HITCOLLDER IS " + hitcolliders[i].gameObject.name);
                    switch (hitcolliders[i].gameObject.name)
                    {
                        case ("RightIn"):
                            east(hitcolliders[i].gameObject);
                            break;
                        case ("LTopCornerIn"):
                            north(hitcolliders[i].gameObject);
                            northWest(hitcolliders[i].gameObject);
                            west(hitcolliders[i].gameObject);
                            break;
                        case ("RTopCornerIn"):
                            north(hitcolliders[i].gameObject);
                            northEast(hitcolliders[i].gameObject);
                            east(hitcolliders[i].gameObject);
                            break;
                        case ("LBottomCornerIn"):
                            south(hitcolliders[i].gameObject);
                            southWest(hitcolliders[i].gameObject);
                            west(hitcolliders[i].gameObject);
                            break;
                        case ("RBottomCornerIn"):
                            south(hitcolliders[i].gameObject);
                            southEast(hitcolliders[i].gameObject);
                            east(hitcolliders[i].gameObject);
                            break;
                        case ("UpIn"):
                            north(hitcolliders[i].gameObject);
                            break;
                        case ("LeftIn"):
                            west(hitcolliders[i].gameObject);
                            break;
                        case ("DownIn"):
                            south(hitcolliders[i].gameObject);
                            break;
                        default:
                            break;
                    }
                }
            }
        }
    }

        

        // Update is called once per frame
        void Update()
        {
        }
    private void north(GameObject gameObject)
        {
        int x = Mathf.RoundToInt(gameObject.transform.position.x);
        int y = Mathf.RoundToInt(gameObject.transform.position.y + 1)-1;
        int z = Mathf.RoundToInt(gameObject.transform.position.z);
        shorePos = new Vector3Int(x,y,z);
        Shore = Instantiate(Shore) as Tile;
        beach.SetTile(shorePos, Shore);
        Debug.Log("TILE SET HERE north" + x + y);
        Debug.Log(gameObject + "gameobject");
    }
    private void northWest(GameObject gameObject)
    {
        int x = Mathf.RoundToInt(gameObject.transform.position.x - 1) - 1;
        int y = Mathf.RoundToInt(gameObject.transform.position.y + 1) - 1;
        int z = Mathf.RoundToInt(gameObject.transform.position.z);
        shorePos = new Vector3Int(x,y,z);
        Shore = Instantiate(Shore) as Tile;
        beach.SetTile(shorePos, Shore);
    }
    private void southWest(GameObject gameObject)
    {
        int x = Mathf.RoundToInt(gameObject.transform.position.x - 1) - 1;
        int y = Mathf.RoundToInt(gameObject.transform.position.y - 1) - 1;
        int z = Mathf.RoundToInt(gameObject.transform.position.z);
        shorePos = new Vector3Int(x,y,z);
        Shore = Instantiate(Shore) as Tile;
        beach.SetTile(shorePos, Shore);
    }
    private void southEast(GameObject gameObject)
    {
        int x = Mathf.RoundToInt(gameObject.transform.position.x + 1) - 1;
        int y = Mathf.RoundToInt(gameObject.transform.position.y - 1) - 1;
        int z = Mathf.RoundToInt(gameObject.transform.position.z);
        shorePos = new Vector3Int(x,y,z);
        Shore = Instantiate(Shore) as Tile;
        beach.SetTile(shorePos, Shore);
    }
    private void south(GameObject gameObject)
        {
        int x = Mathf.RoundToInt(gameObject.transform.position.x);
        int y = Mathf.RoundToInt(gameObject.transform.position.y - 1) - 1;
        int z = Mathf.RoundToInt(gameObject.transform.position.z);
        shorePos = new Vector3Int(x,y,z);
        Shore = Instantiate(Shore) as Tile;
        beach.SetTile(shorePos, Shore);
        Debug.Log("TILE SET HERE south" + x + y);
        Debug.Log(gameObject + "gameobject");
    }
    private void northEast(GameObject gameObject)
    {
        int x = Mathf.RoundToInt(gameObject.transform.position.x - 1) + 1;
        int y = Mathf.RoundToInt(gameObject.transform.position.y + 1) - 1;
        int z = Mathf.RoundToInt(gameObject.transform.position.z);
        shorePos = new Vector3Int(x,y,z);
        Shore = Instantiate(Shore) as Tile;
        beach.SetTile(shorePos, Shore);

    }
    private void west(GameObject gameObject)
        {
        int x = Mathf.RoundToInt(gameObject.transform.position.x - 1) - 1;
        int y = Mathf.RoundToInt(gameObject.transform.position.y);
        int z = Mathf.RoundToInt(gameObject.transform.position.z);
        shorePos = new Vector3Int(x,y,z);
        Shore = Instantiate(Shore) as Tile;
        beach.SetTile(shorePos, Shore);
        Debug.Log("TILE SET HERE west at" + x + y);
        Debug.Log(gameObject + "gameobject");
    }
    private void east(GameObject gameObject)
        {
        int x = Mathf.RoundToInt(gameObject.transform.position.x + 1) -1;
        int y = Mathf.RoundToInt(gameObject.transform.position.y);
        int z = Mathf.RoundToInt(gameObject.transform.position.z);
        shorePos = new Vector3Int(x,y,z);
        Shore = Instantiate(Shore) as Tile;
        beach.SetTile(shorePos, Shore);
        Debug.Log("TILE SET HERE" + x + y);
        Debug.Log(gameObject + "gameobject");
    }
    }
