﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
[System.Serializable]
public class Bone : CheckValues
{
    public float speed = 2.0f;
    public Vector3 pos;
    public Transform tr;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Bone == true)
        {
            for (int i = 0; i < 10; i++)
            {
                pos += Vector3.down;
                transform.position = Vector3.MoveTowards(transform.position, pos, Time.deltaTime * speed);
            }
            for (int i = 0; i < 12; i++)
            {
                pos += Vector3.left;
                transform.position = Vector3.MoveTowards(transform.position, pos, Time.deltaTime * speed);
            }
        }
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            int y = (SceneManager.GetActiveScene().buildIndex + 1);
            if (y < 4)
            {
                SceneManager.LoadScene("Level" + y);
            }
            if(y == 4)
            {
                Application.Quit();
            }
        }
    }
}
